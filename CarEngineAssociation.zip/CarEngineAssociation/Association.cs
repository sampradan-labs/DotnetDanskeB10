﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarEngineAssociation
{
    //Car HAS-A Engine
    public class Car
    {
        //Property
        public Engine CarEngine { get; set; }

        //Constructor to a method
        public Car(Engine pEngine, bool? pValue) //?- implies you can pass null value here
        {
            CarEngine = pEngine;
        }

        //Parameter to method
        public void AddEngine(Engine pEngine)
        {
            CarEngine = pEngine;
        }
    }

    public class Engine
    {
        public string Brand { get; set; }
    }
}
