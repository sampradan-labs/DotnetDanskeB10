﻿using System;
using System.Collections.Generic;

namespace CarEngineAssociation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Engine Suzuki = new Engine();
            Car MarutiDezire = new Car(Suzuki, true);

            //manufacture a toy car
            Car toyCar = new Car(null, null);
            int? i;
            List<string>? lst;            

        }
    }
}
