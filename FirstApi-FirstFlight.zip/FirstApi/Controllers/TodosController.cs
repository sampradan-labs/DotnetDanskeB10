﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using TodoLibrary;

namespace FirstApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TodosController : ControllerBase
    {
        TodoOperations _dataContext = new TodoOperations();

        [HttpGet("/todos/better")]
        public IActionResult GetBetterTodos()
        {
            return Ok(_dataContext.GetAllTodos());  //http response object created with data as output of GetAllTodos()
                                                    //and forces the http status code = 200 (successful)
        }

        [HttpPost("/todos/better/add")]
        public IActionResult AddBetterTodo([FromBody] Todo pTodo)
        {
            try
            {
                _dataContext.GetAllTodos();
                _dataContext.CreateTodo(pTodo.Title);
                return Created("/better/todos", $"Todo: {pTodo.Title} created successfully");   //Create http response object with data as returned string
                                                                                         // and force status code to be 201
            }
            catch(Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        //Traditional Way..//

        [HttpGet("/todos")]
        public List<Todo> GetTodos()
        {
            return _dataContext.GetAllTodos();
        }

        [HttpPost("/todo/create")]
        public string AddTodo([FromBody] Todo pTodo)
        {
            _dataContext.GetAllTodos();
            _dataContext.CreateTodo(pTodo.Title);
            return $"Todo: {pTodo.Title} created successfully";
        }
    }
}
