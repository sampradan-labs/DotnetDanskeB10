﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace FirstApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SimpleController : ControllerBase
    {
        

        [HttpGet("/items")]
        public string[] GetItems()
        {
            return new string[] { "Apparels", "Groceries", "Mobiles" };            
        }

        private static List<string> names;

        [HttpGet("/names")]
        public List<string> GetNames()
        {
            if (names == null)
            {
                names = new List<string>();
                names.Add("Eena");
                names.Add("Meena");
                names.Add("Deeka");
            }
            return names;
        }

        [HttpGet("/find/{pName}/{id}")]
        public string FindName(string pName, int id)
        {
            var itemName = "";
            foreach (var item in names)
            {
                if (item == pName)
                {
                    return $"Person found with name {item}-{id}";
                }
            }

            return $"Person not found";
        }

        [HttpPost("/add/{pName}")]
        public string AddName(string pName)
        {
            GetNames();
            names.Add(pName);
            return $"Name added to list {pName}";
        }

        [HttpPut("/update/{pName}/{pNewName}")]
        public string Update(string pName, string pNewName)
        {
            GetNames();
            for (int i = 0; i < names.Count; i++)
            {
                if (names[i] == pName)
                {
                    names[i] = pNewName;
                    return $"Name changed from {pName} to {pNewName}";
                }
            }
            return $"Name not found";
        }

        [HttpPost("/add")]
        public string AddNameSecretly([FromBody] string pName)
        {
            GetNames();
            names.Add(pName);
            return $"Name added to list {pName}";
        }
    }
}
