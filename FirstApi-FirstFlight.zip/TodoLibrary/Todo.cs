﻿using System;

namespace TodoLibrary
{
    public class Todo
    {
        public string Title { get; set; }
        public bool IsCompleted { get; set; }
        public int Id { get; set; }

    }
}
