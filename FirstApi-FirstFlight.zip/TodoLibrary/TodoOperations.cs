﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TodoLibrary
{
    public class TodoOperations
    {
        private static List<Todo> _todos;
        public bool CreateTodo(string pName, bool isCompleted=false)
        {
            try
            {
                Todo todo = new Todo();
                todo.Id = new Random().Next();
                todo.Title = pName;
                todo.IsCompleted = isCompleted;

                _todos.Add(todo);
                return true;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public List<Todo> GetAllTodos()
        {
            if (_todos == null)
            {
                _todos = new List<Todo>();
                Todo _sample = new Todo()
                {
                    Id = new Random().Next(),
                    Title = "Test Todo",
                    IsCompleted = true
                };

                _todos.Add(_sample);
            }
            return _todos;
        }

        public bool UpdateTodo(string pName, Todo pToBeUpdated)
        {
            try
            {
                foreach (var item in _todos)
                {
                    if (item.Title == pName)
                    {
                        item.IsCompleted = pToBeUpdated.IsCompleted;
                        item.Title = pToBeUpdated.Title;
                        break;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool DeleteTodo(string pName)
        {
            Todo _temp=new Todo();
            try
            {
                foreach (var item in _todos)
                {
                    if (item.Title == pName)
                    {
                        //_todos.Remove(item);
                        _temp = item;
                        break;
                    }
                }

                if (_temp.Title != null || _temp.Title != String.Empty)
                {
                    _todos.Remove(_temp);
                    return true;
                }
                return false;
               
            }
            catch(Exception ex)
            {
                throw ex;
            }

        }
    }
}
