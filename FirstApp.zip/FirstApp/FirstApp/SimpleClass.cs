﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes{
    internal class SimpleClass
    {
        public SimpleClass()
        { iAmReadOnly = 1; }
        protected SimpleClass(int pId, string empId)
        {
            this.Id = pId;
            this.EmpId = empId; 
        }
        internal SimpleClass(string pPrefix)
        {
            _empPrefix = pPrefix;
            SomeMethod();
        }

        private void SomeMethod()
        {
            Console.WriteLine("In SomeMethod()");
        }

        private SimpleClass(bool pIsOk)
        {  pIsOk = true; }

        //Class Variable - Field
        public const string ERROR_MSG = "ERROR CODE 404: Not Found";
        public readonly int iAmReadOnly;

        //properties
        private string _empId = "";
        public string EmpId
        {
            get { return _empId; }
            set { _empId = $"{_empPrefix}-{value}"; } //SIEMENS-1001
        }
        public int Id { get; set; } //auto-property

        //temporary variables
        private string _empPrefix = "DANSKE";
       

        //methods
        public string[] GetAllItems()
        {
            string[] strItems = new string[] {"Apparels","Groceries","Mobiles", "Discount Coupons" };
            int[] intCost = new int[] { 100, 200, 300, 400 };
            string[] arrResult = new string[strItems.Length];

            //check if strItems.Count == intCost.Count
            if (strItems.Length == intCost.Length)
            {
                for (int i = 0; i < strItems.Length; i++)
                {
                    arrResult[i] = $"{strItems[i]} costs INR {intCost[i]}"; //Apparels-100
                }
            }
            else
            {
                throw new Exception("All items do not have costs configured");
            }

            return arrResult;
        }
        //Reversing a string. Eg: string name = Neha ; output = ahaN
        //for(int i=name.Length-1; i>=0; i++){}


        //destructor: Auto-created if you forget to add
    }
}
