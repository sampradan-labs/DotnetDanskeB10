﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Print
{
    class Program
    {
        TestPrograms.Test.TestPr objTestPr = new TestPrograms.Test.TestPr();
        //objTestPr.SubClass
    }
}

namespace TestPrograms
{
    namespace Test
    {
        class TestPr
        {
            int i;
            FirstApp.Program fPrg;  //syntax: custom-datatype variable-name
            Print.Program fPrgPrint;
            TestPrograms.Test.TestPr testPr;

            class SubClass
            {

            }
        }
    }
}
