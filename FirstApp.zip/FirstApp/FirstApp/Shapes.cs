﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstApp
{
    //abstract = incomplete
    public abstract class Shape
    {
        public Shape()
        {
            Color = "Blue";
        }
        public abstract void Draw();

        public string Color { get; set; }
        public virtual void Fill()
        {
            Console.WriteLine($"The shape is filled with {Color} color");
        }
    }   
    public class Circle : Shape {

        public override void Draw()
        {
            Console.WriteLine($"Circle shape drawn having radius {Radius}");
        }
        public Circle(float radius)
        {
            Radius = radius;
        }

        public float Radius { get; set; }
        public float GetArea()
        {
            return 3.14f * Radius * Radius;
        }

        //Giving the derived class permissions to change the logic of this method
        public virtual float GetPerimeter()
        {
            return 2 * 3.14f * Radius;
        }
    }

    public class Ellipse : Circle {

        public override void Draw()
        {
            Console.WriteLine($"Ellipse drawn with r1={Radius}, r2= {Radius2}");
        }

        public override void Fill()
        {
            base.Fill();
        }

        public Ellipse(float r1, float r2):base(r1)
        {
            Radius2 = r2;
        }

        public float Radius2 { get; set; }

        //shadowing or Method Hiding
        public float GetArea()
        {
            return 3.14f * Radius * Radius2;
        }

        public override float GetPerimeter()
        {
            return 2 * 3.14f * Radius * Radius2;
        }
    }


    public class Rectangle : Shape
    {
        public override void Draw()
        {
            Console.WriteLine($"Rectangle with length={Length}, Breadth={Breadth} is drawn");
        }
        public Rectangle(int pLength, int pBreadth)
        {
            Length = pLength;
            Breadth = pBreadth;
        }
        public int Length { get; set; }
        public int Breadth { get; set; }
        public int Area { get; set; }

        public int GetArea()
        {
            return Length * Breadth;
        }

    }

    public class Square : Rectangle
    {
        public Square(int pSide) : base(pSide, pSide)
        {

        }
    }

}
