﻿using System;   //import external or .net references
using Print;
using TestPrograms.Test;
using Classes;

namespace FirstApp  //logical grouping of .net entities: class, events, global vars, delegates, enums etc
{
    internal class Program
    {
       static void StaticVsInstanceMethod()
        {
            //ClassName.MethodName()
            Program.SetPrefix();    
            Program prg = new Program();
            prg.SomeMethod();
        }

        static void SetPrefix()
        {
            Console.WriteLine("Prefix is FirstApp");
        }

        void SomeMethod()
        {
            Console.WriteLine("In SomeMethod()");
        }

        static void Main(string[] args)
        {
            //ReadLineWriteLine();

            ////Static Vs Non-Static
            //Program.StaticVsInstanceMethod();

            //WorkingWithSimpleClass();
            //WorkingWithInheritance();

            //CircularShapeVendor();

            AllShapesVendor();
        }

        private static void AllShapesVendor()
        {
            do
            {
                Console.WriteLine("Which shape do you wish to purchase?");
                string shape = Console.ReadLine();
                Shape s = GetShapeObject(shape);
                s.Draw();
                s.Fill();

                //Here we are pulling out rectangle's properties if the real type of 's' is Rectangle
                if (s.GetType() == typeof(Rectangle))
                {
                    Rectangle _tempRect = (Rectangle)s; //typecasting
                    Console.WriteLine($"Calling GetArea() which is inside the Rectangle class: {_tempRect.GetArea()}");
                }
                Console.WriteLine("Do you wish to make further purchases?");
            } while (Console.ReadLine() != "n");
        }

        private static Shape GetShapeObject(string shape)
        {
            switch (shape.ToLower())
            {
                case "rectangle":
                    Shape s = new Rectangle(10, 5);
                    return s;
                case "square":
                    return new Square(10);
                case "circle":
                    return new Circle(5);
                case "ellipse":
                    return new Ellipse(10, 5);
                default:
                    throw new Exception("Invalid Shape");
            }
        }

        private static void CircularShapeVendor()
        {
            //Customer input
            Console.WriteLine("Which circular shape do you wish to purchase?");
            string shape = Console.ReadLine();
            //The vendor makes the calls - in static void Main()
            Circle circularShape = GetCircularShapes(shape);
            Console.WriteLine($"Technical Specs of requested Shape: Perimeter: " +
                              $"{circularShape.GetPerimeter()} | " +
                              $"Total Area: {circularShape.GetArea()}");
            Ellipse e1 = new Ellipse(10, 4);
            Console.WriteLine($"Area of Ellipse: {e1.GetArea()}");
        }

        public static Circle GetCircularShapes(string pCustomerRequestedShape)
        {
            switch (pCustomerRequestedShape.ToLower())
            {
                case "circle":
                    Console.WriteLine("Enter radius: ");
                    string radius = Console.ReadLine();
                    float fr = Convert.ToSingle(radius);
                    return new Circle(fr);

                case "ellipse":
                    //Take r1, r2 from customer
                    Console.WriteLine("Enter value for r1");
                    string r1 = Console.ReadLine();
                    Console.WriteLine("Enter value for r2");
                    string r2 = Console.ReadLine();
                    //The vendor makes the calls
                    float fr1 = Convert.ToSingle(r1);
                    float fr2 = Convert.ToSingle(r2);
                    Circle sc1 = new Ellipse(fr1, fr2);                    
                    return sc1;

               
                default:
                    throw new Exception("Invalid Shape");
                    
            }
        }

        private static void WorkingWithInheritance()
        {
            Rectangle r1 = new Rectangle(10, 5);
            Square s1 = new Square(10);
            Circle c1 = new Circle(10);
            Ellipse e1 = new Ellipse(10, 20);

            Console.WriteLine($"Area of {nameof(r1)} = {r1.GetArea()}");
            Console.WriteLine($"Area of {nameof(s1)} = {s1.GetArea()}");
            Console.WriteLine($"Area of  {nameof(c1)} = {c1.GetArea()}");
            Console.WriteLine($"Area of  {nameof(e1)} = {e1.GetArea()}");
        }

        private static void WorkingWithSimpleClass()
        {
            SimpleClass objS1 = new SimpleClass();
            SimpleClass objS2 = new();  //C# 8  syntax
            SimpleClass objS3 = new SimpleClass("DAIMLER");
            SimpleClass objS4 = new("SIEMENS");

            //Change & Print Properties
            objS1.EmpId = "1001";   //cals the set method
            objS2.EmpId = "2002";
            objS3.EmpId = "3003";
            objS4.EmpId = "4004";

            string[] result =  objS1.GetAllItems();
            foreach (var item in result)
            {
                Console.WriteLine(item);
            }

            //Print the values of objects
            Console.WriteLine($"{nameof(objS1)} has EmpId= {objS1.EmpId}");   //calls get
            Console.WriteLine($"objS2 has EmpId= {objS2.EmpId}");
            Console.WriteLine($"objS3 has EmpId= {objS3.EmpId}");
            Console.WriteLine($"objS4 has EmpId= {objS4.EmpId}");
        }

        private static void ReadLineWriteLine()
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("Enter your name:");
            string userInput = "";
            string age;
            userInput = Console.ReadLine(); //whatever user enters
            Console.WriteLine("Enter your age: ");
            age = Console.ReadLine();

            //Print the greeting
            Console.WriteLine("Namaste " + userInput + " " + age);
            Console.WriteLine($"Namaste {userInput} is {age}yrs old");  //string interpolation = $" {variable}"
        }
    }
}

