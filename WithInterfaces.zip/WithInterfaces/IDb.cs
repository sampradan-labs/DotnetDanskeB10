﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WithInterfaces
{
    public interface IDb
    {
        string SelectQuery(string tableName, string[] columns);
        string CreateQuery(string tableName, string[] columns);
        string UpdateQuery(string tableName, string[] columns);
        string DeleteQuery(string tableName, string[] columns);

        string ConnectionString { get; set; }
    }
    public interface IDbConnection
    {
        
    }

    public class SqlServer : IDb, IDbConnection
    {
      
        public string ConnectionString { get; set; }

        public string CreateQuery(string tableName, string[] columns)
        {
            string query = "create table with ";
            foreach (var col in columns)
            {
                //query = query + " " + col
                query += $" {col},";
            }
            //query= "create table with Id, Name,"
            query = query.Trim(',');

            query += $" as {tableName}";
            //query = "create table with Id, Name from Emp"
            return query;
        }

        public string DeleteQuery(string tableName, string[] columns)
        {
            string query = "delete table with columns";
            foreach (var col in columns)
            {
                //query = query + " " + col
                query += $" {col},";
            }
            //query= "delete table with Id, Name,"
            query = query.Trim(',');

            query += $" as {tableName}";
            //query = "delete table with Id, Name as Emp"
            return query;
        }

        public string SelectQuery(string tableName, string[] columns)
        {
            string query = "select ";
            foreach (var col in columns)
            {
                //query = query + " " + col
                query += $" {col},";
            }
            //query= "create table with Id, Name,"
            query = query.Trim(',');

            query += $" from {tableName}";
            //query = "create table with Id, Name from Emp"
            return query;
        }

        public string UpdateQuery(string tableName, string[] columns)
        {
            string query = "update table set new columns as ";
            foreach (var col in columns)
            {
                //query = query + " " + col
                query += $" {col},";
            }
            //query= "create table with Id, Name,"
            query = query.Trim(',');

            query += $" in {tableName}";
            //query = "create table with Id, Name from Emp"
            return query;
        }
    }

    public class FileDB : IDb
    {
        public string ConnectionString { get; set; }

        public string CreateQuery(string tableName, string[] columns)
        {
            string data = "";
            foreach (var item in columns)
            {
                data += $" {item}";
            }
            return $"type {tableName} --text {data}";
        }

        public string DeleteQuery(string tableName, string[] columns)
        {
            string data = "";
            foreach (var item in columns)
            {
                data += $" {item}";
            }
            return $"del ./{tableName} --text {data}";
        }

        public string SelectQuery(string tableName, string[] columns)
        {
            string data = "";
            foreach (var item in columns)
            {
                data += $" {item}";
            }
            return $"notepad ./{tableName} --text {data}";
        }

        public string UpdateQuery(string tableName, string[] columns)
        {
            string data = "";
            foreach (var item in columns)
            {
                data += $" {item}";
            }
            return $"save ./{tableName} --text {data}";
        }
    }
}
