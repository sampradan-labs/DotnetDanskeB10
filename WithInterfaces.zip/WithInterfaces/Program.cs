﻿using System;

namespace WithInterfaces
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Base = new Derived()
            Console.WriteLine("Enter a dbms");
            string dbms = Console.ReadLine();
            IDb objDbms = GetDbms(dbms);
            Console.WriteLine($"SelectQuery : {objDbms.SelectQuery("Employee", new string[]{"Id", "Name", "Designation"})}");
            Console.WriteLine($"CreateQuery : {objDbms.CreateQuery("Employee", new string[] { "Id", "Name", "Designation" })}");
            Console.WriteLine($"DeleteQuery : {objDbms.DeleteQuery("Employee", new string[] { "Id", "Name", "Designation" })}");
            Console.WriteLine($"UpdateQuery : {objDbms.UpdateQuery("Employee", new string[] { "Id", "Name", "Designation" })}");
        }

        private static IDb GetDbms(string dbms)
        {
            switch (dbms.ToLower())
            {
                case "sql":
                    return new SqlServer();
                case "file":
                    return new FileDB();

                default:
                    throw new Exception("Invalid dbms");
            }
        }
    }
}
